from SDM15 import SDM15, BaudRate
import csv
import serial
import threading
import time

def read_arduino_data(arduino_serial, arduino_data, stop_event):
    while not stop_event.is_set():
        try:
            line = arduino_serial.readline().decode('utf-8').strip()
            if line:
                # 아두이노에서 보내는 시간 값 파싱
                if line.startswith("Current Rotation Time:"):
                    parts = line.split(":")
                    if len(parts) > 1:
                        time_part = parts[1].strip()
                        time_value = time_part.split(" ")[0]  # 시간 값 (초 단위)
                        arduino_data['time'] = time_value
                elif line.startswith("Total Rotation Time:"):
                    # 총 회전 시간 수신 시 종료 플래그 설정
                    arduino_data['total_time'] = line
                    stop_event.set()  # 메인 루프에 종료 신호 전달
                else:
                    # 다른 출력 처리 (필요한 경우)
                    pass
        except Exception as e:
            print(f"Error reading Arduino data: {e}")
            pass

        
if __name__ == "__main__":
    try:
        lidar = SDM15("COM3", BaudRate.BAUD_460800) # tof 센서 포트

        version_info = lidar.obtain_version_info()
        print("get version info success")

        lidar.lidar_self_test()
        print("self test success")

        lidar.start_scan()

        # 아두이노 시리얼 포트 설정 (아두이노가 연결된 포트로 변경)
        arduino_port = 'COM6'  # 아두이노가 연결된 시리얼 포트
        arduino_baudrate = 9600

        # 아두이노 시리얼 연결
        arduino_serial = serial.Serial(arduino_port, arduino_baudrate, timeout=1)

        # 아두이노 데이터를 저장할 딕셔너리
        arduino_data = {'time': None, 'total_time': None}
        
        # 스레드 종료를 위한 이벤트 객체 생성
        stop_event = threading.Event()

        # 아두이노 데이터를 읽어오는 스레드 시작
        arduino_thread = threading.Thread(target=read_arduino_data, args=(arduino_serial, arduino_data))
        arduino_thread.daemon = True
        arduino_thread.start()
        
        # Open a CSV file to write data
        with open('lidar_data.csv', mode='w', newline='') as file:
            writer = csv.writer(file)
            # Write header row
            writer.writerow(["Time","Distance", "Intensity"])
            
            last_time_value = None  # 마지막으로 받은 시간 값 저장

            while not stop_event.is_set():
                try:
                    distance, intensity, _ = lidar.get_distance()
                    # 아두이노에서 시간 값 가져오기
                    time_value = arduino_data.get('time')
                    # total_time_value = arduino_data.get('total_time')
                    if time_value is not None:
                        last_time_value = time_value  # 최신 시간 값 업데이트
                        arduino_data['time'] = None   # 시간 값 사용 후 초기화
                    if last_time_value is None:
                        # 아직 시간 값을 받지 못한 경우
                        print("Waiting for time data from Arduino...")
                        continue  # 다음 루프로 넘어감
                    
                    print(f"time: {last_time_value}, distance: {distance}, intensity: {intensity}")
                    # Write data to CSV
                    writer.writerow([last_time_value, distance, intensity])
                    
                    # 실시간 데이터 저장을 위해 버퍼 플러시
                    file.flush()
                except KeyboardInterrupt:
                    print("Stopping data recording due to KeyboardInterrupt")
                    stop_event.set()  # 종료 이벤트 설정

                except Exception as e:
                    print(f"An error occurred: {e}")
                    stop_event.set()  # 종료 이벤트 설정

    finally:
        # 프로그램 종료 시 리소스 정리
        lidar.stop_scan()
        arduino_serial.close()
        print("All resources closed and program terminated.")
# https://github.com/being24/YDLIDAR-SDM15_python
 
    # # Open a CSV file to write data
    # with open('lidar_data.csv', mode='w', newline='') as file:
    #     writer = csv.writer(file)
    #     # Write header row
    #     writer.writerow(["Distance", "Intensity", "Disturb"])
        
    #     while True:
    #         try:
    #             distance, intensity, disturb = lidar.get_distance()
    #             print(f"distance: {distance}, intensity: {intensity}, disturb: {disturb}")
    #             # Write data to CSV
    #             writer.writerow([distance, intensity, disturb])        
    #         except KeyboardInterrupt:
    #             print("Stopping data recording")
    #             break